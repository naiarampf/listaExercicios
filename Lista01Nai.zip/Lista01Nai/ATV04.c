'#include <stdlib.h>
#include <stdio.h>

int main(){
int num = 0 , multiplo = 0;
 while( multiplo < 5){
    if(num % 3 == 0){
   if(multiplo == 4){
        printf("%d.", num);
   }else{
       printf("%d ,", num);
   }
multiplo++;
num++;
}else{
    num++;

}

}
return 0;
   }
