#include <stdlib.h>
#include <stdio.h>

int main(){
int num;
printf("Digite um numero positivo: ");
scanf("%d", &num);
for(int i = 0; i <= num; i++){
    if(i == num){
        printf("%d. ", i);
    } else {
        printf("%d, ", i);
    }
}
return 0;
}
