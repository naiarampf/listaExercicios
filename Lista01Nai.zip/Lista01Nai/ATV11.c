#include <stdlib.h>
#include <stdio.h>

int main(){
    int num;
    printf("Digite um numero para saber seus divisores: ");
    scanf("%d", &num);
    printf("Divisores de %d:\n", num);
    for(int i = 1; i <= num; i++){
        if(num % i == 0){
            if(i == num){
                printf("%d. ", i);
            } else {
                printf("%d, ", i);
            }
        }
    }
    return 0;
}
