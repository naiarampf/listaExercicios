#include <stdio.h>

double maior(double a, double b){
    if(a > b){
        return(a);
    } else {
        return(b);
    }
}

int main() {

    double a, b;
    printf ("Digite o primeiro numero: ");
    scanf("%d", &a);
    printf ("Digite o segundo numero: ");
    scanf("%d", &b);
    printf("O maior numero � %d.", maior(a, b));
}
