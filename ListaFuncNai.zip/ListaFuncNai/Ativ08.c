#include <stdio.h>
#include <stdlib.h>

int soma_Vetor(int *vet){
    int sum = 0;
        for(int i = 0; i < 10; i++){
            sum += *(vet + i);
        }
    return sum;
}

int main() {

    int vet[10];
    for ( int i = 0; i < 10; i++){
        printf("Digite um valor: ");

        scanf("%d", &vet[i]);
    }
    for ( int i = 0; i < 10; i++){
        if( i == 9){
            printf("%d.", vet[i]);
        } else {
            printf("%d, ", vet[i]);
        }
    }
    printf("\nSoma dos numeros dentro do vetor: %d", soma_Vetor(vet));
}
