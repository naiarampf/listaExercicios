#include <stdio.h>
#include <stdlib.h>

void valida_num(int *num);

int main(){
    int value;
    printf("Digite um numero: ");
    scanf("%d", &value);
    valida_num(&value);
    printf("Valor: %d", value);
    return 0;
}

void valida_num(int *num){
    if(*num < 0){
        *num = 0;
    } else {
        *num = *num* 5;
    }
}
