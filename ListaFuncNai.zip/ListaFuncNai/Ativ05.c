#include <stdio.h>
#include <stdlib.h>

void imprime(int qtd);

int main(){
    imprime(5);
    return 0;
}

void imprime(int qtd){
    for(int i = 0; i < qtd; i++){
        for(int j = 0; j <= i; j++){
            printf("!");
        }
        printf("\n");
    }
}
