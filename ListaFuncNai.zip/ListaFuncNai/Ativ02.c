#include <stdio.h>

float conversao(float *C, float *F){
    *C = (*F-32) / 1.8;
    return *C;
}

int main() {

    float C, F;
    printf ("Digite a temperatura em Fahrenheit: ");
    scanf("%f", &F);
    conversao(&C, &F);
    printf("A temperatura %.2f F convertida em Celcius e de %.2f C\n\n", F, C);

}
