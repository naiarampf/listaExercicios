#include <stdio.h>

int operador(int *H, int *M, int *S){
    return *S = *S + (*H * 3600) + (*M * 60);
}

int main() {

    int H, M, S;
    printf ("Digite um valor para horas (Entre 0 e 23): ");
    scanf("%d", &H);
    printf ("\nDigite um valor para minutos (Entre 0 e 59): ");
    scanf("%d", &M);
    printf ("\nDigite um valor para segundos (Entre 0 e 59): ");
    scanf("%d", &S);

    printf("\nHora digitada: %d:%d.%d = (%d horas, %d minutos, %d segundos)", H, M, S, H, M, S);

    operador(&H, &M, &S);
    printf("\n\nHora convertida para segundos:\n\nTotal em segundos: %d segundos.", S);

}
