#include <stdio.h>
#include <stdlib.h>

int somar_Vinte(int *num){
    return *num = *num + 20;
}

int main() {

    int x;
    printf("Digite um numero para somar com 20: ");
    scanf("%d", &x);

    printf("Valor x antes de somar: %d.", x);

    somar_Vinte(&x);

    printf("\nValor x apos somar com 20: %d.", x);

}
