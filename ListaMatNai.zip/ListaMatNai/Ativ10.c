#include <stdio.h >
#include <stdlib.h>
#define TAM 5


int main(){
    int A[TAM][TAM];
    int B[TAM][TAM];

    for(int i = 0; i < TAM; i++){
        for(int j = 0; j < TAM; j++){
            A[i][j] = rand() % 50;
            B[i][j] = A[i][j] * 2;
        }
    }

    printf("\nA:\n");

    for(int i = 0; i < TAM; i++){
        for(int j = 0; j < TAM; j++){
            printf("%d\t", B[i][j]);
        }
        printf("\n");
    }

    printf("\nB:\n");

    for(int i = 0; i < TAM; i++){
        for(int j = 0; j < TAM; j++){
            printf("%d\t", B[i][j]);
        }
        printf("\n");
    }

return 0;

}
