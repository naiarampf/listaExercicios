#include <stdio.h >
#include <stdlib.h>
#define LEN 5

int main()
{
    int lin, col, soma = 0, soma_diagonal_secund = 0;
    int matriz[LEN][LEN];

    for(lin = 0; lin < LEN; lin++){
        for(col = 0; col < LEN; col++){
            printf("Digite os valores: ");
            scanf("%d", &matriz[lin][col]);
            soma = soma + matriz[lin][col];
        }
    }
    printf("\n");

    for(lin = 0; lin < LEN; lin++){
        for(col = 0; col < LEN; col++){
            if (LEN - col - lin == 1){
                printf("%d ", matriz[lin][col]);
                soma_diagonal_secund = soma_diagonal_secund + matriz[lin][col];
            } else {
                printf("%d ", matriz[lin][col]);
            }
        }
    printf("\n");
    }
    printf("\n\nA soma dos valores: %d\n", soma);
    printf("A soma da diagonal secundaria: %d\n\n",soma_diagonal_secund);
 return 0;
}
