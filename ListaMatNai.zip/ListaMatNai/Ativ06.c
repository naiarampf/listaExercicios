#include <stdio.h >
#include <stdlib.h>

int main()
{
    int lin, col, soma = 0, soma_diagonal = 0;
    int matriz[3][3];

    for(lin = 0; lin < 3; lin++){
        for(col = 0; col < 3; col++){
            printf("Digite os valores: ");
            scanf("%d", &matriz[lin][col]);
            soma = soma + matriz[lin][col];
        }
    }
    printf("\n");

    for(lin = 0; lin < 3; lin++){
        for(col = 0; col < 3; col++){
            if (lin == col){
                printf("%d ", matriz[lin][col]);
                soma_diagonal = soma_diagonal + matriz[lin][col];
            } else {
                printf("%d ", matriz[lin][col]);
            }
        }
    printf("\n");
    }
    printf("\n\n A soma dos valores: %d\n", soma);
    printf("A soma da diagonal principal: %d\n\n",soma_diagonal);
 return 0;
}
