#include <stdio.h >
#include <stdlib.h>


int main(){
    int matriz[10][10];

    for(int i = 0; i < 10; i++){
        for(int j = 0; j < 10; j++){
           if(i == j){
           matriz[i][j] = 0;
           } else if (i < j){
           matriz[i][j] = 1;
           }else {
           matriz[i][j] = 2;
           }
         printf("%d \t ", matriz[i][j]);
        }
        printf("\n");
    }

return 0;

}
