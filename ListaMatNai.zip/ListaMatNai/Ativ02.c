#include <stdlib.h>;
#include <stdio.h>;

int main(){
    int matriz[4][4], posLinMaior = 0, posColMaior = 0;
    int maior = 0, lin, col;
    for( lin = 0; lin < 4; lin++){
        for( col = 0; col < 4; col++){
            printf("Digite um numero: ");
            scanf("%d", &matriz[lin][col]);
            if( matriz[lin][col] > maior){
                maior = matriz[lin][col];
                posLinMaior = lin;
                posColMaior = col;
            }
        }
    }

    printf("\nNumeros da matriz:\n");

    for( lin = 0; lin < 4; lin++){
        for( col = 0; col < 4; col++){
            if(lin == 3 && col == 3){
                printf("%d.", matriz[lin][col]);
            } else {
                printf("%d, \t", matriz[lin][col]);
            }
            if(col == 3){
                printf("\n");
            }
        }
    }

    printf("\nMaior numero na matriz: %d.", maior);
    printf("\nPosicao na matriz: matriz[%d][%d]", posLinMaior+1, posColMaior+1);
}

