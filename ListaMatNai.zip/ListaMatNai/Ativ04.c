#include <stdlib.h>;
#include <stdio.h>;

int main(){
    int matriz[4][4], maior10 = 0;
    for( int lin = 0; lin < 4; lin++){
        for( int col = 0; col < 4; col++){
            printf("Digite um numero: ");
            scanf("%d", &matriz[lin][col]);
            if( matriz[lin][col] > 10){
                maior10++;
            }
        }
    }

    printf("\nNumeros da matriz:\n");

    for( int lin = 0; lin < 4; lin++){
        for( int col = 0; col < 4; col++){
            if(lin == 3 && col == 3){
                printf("%d.", matriz[lin][col]);
            } else {
                printf("%d, \t", matriz[lin][col]);
            }
            if(col == 3){
                printf("\n");
            }
        }
    }
    printf("\nQuantidade de numeros maiores que 10 na matriz: %d.", maior10);
}
