#include <stdio.h >
#include <stdlib.h>
#define LEN 5


int main(){
    int mat[LEN][LEN], sum = 0;

    for(int i = 0; i < LEN; i++){
        for(int j = 0; j < LEN; j++){
            mat[i][j] = rand() % 50;
        }
    }

    for(int i = 0; i < LEN; i++){
        for(int j = 0; j < LEN; j++){
            if (i < j){
                printf("[%d]\t", mat[i][j]);
            } else {
                printf("%d\t", mat[i][j]);
            }
        }
        printf("\n");
    }

    for(int i = 0; i < LEN; i++){
        for(int j = 0; j < LEN; j++){
            if (i < j){
                sum = sum + (mat[i][j] + mat[i][j]);
            }
        }
    }

    printf("\nSoma dos numeros acima da diagonal principal: %d\n", sum);

return 0;

}
