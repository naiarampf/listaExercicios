#include <stdlib.h>;
#include <stdio.h>;

int main(){
    int matriz[3][3];
    int menor = 1000;
    for(int lin = 0; lin < 3; lin++){
        for(int col = 0; col <3; col++){
            printf("Digite um numero: ");
            scanf("%d", &matriz[lin][col]);
            if( matriz[lin][col] < menor){
                menor = matriz[lin][col];
            }
        }
    }

    printf("Numeros da matriz:\n");

    for(int lin = 0; lin < 3; lin++){
        for(int col = 0; col <3; col++){
            if(lin == 2 && col == 2){
                printf("%d.", matriz[lin][col]);
            } else {
                printf("%d, ", matriz[lin][col]);
            }
        }
    }

    printf("\nMenor numero na matriz: %d.", menor);
}

