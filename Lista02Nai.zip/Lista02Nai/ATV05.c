#include <stdlib.h>
#include <stdio.h>

int main(){
int i = 1, par = 0, soma = 0;
while(par < 50){
if(i % 2 == 0){
    if(par == 49){
        printf("%d. ", i);
        } else {
            printf("%d, ", i);
        }
        soma = soma + i;
        par++;
        i++;
    } else {
    i++;
    }

}
printf("\nSoma: %d. ", soma);
return 0;
}
