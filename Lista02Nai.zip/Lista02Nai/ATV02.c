#include <stdlib.h>
#include <stdio.h>

int main(){
int num;
printf("Digite um numero positivo: ");
scanf("%d", &num);
for(int i = num; i >= 0; i--){
    if(i == 0){
        printf("%d. ", i);
    } else {
        printf("%d, ", i);
    }
}
return 0;
}
