#include <stdlib.h>
#include <stdio.h>

int main(){
    int num = 10;

    for(int i = num ;i >= 0; i--){
        if(i == 0){
            printf("%d , FIM", i);
        }else{
            printf("%d,", i);
        }
    }
return 0;
}
