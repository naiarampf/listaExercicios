#include <stdio.h>
#include <stdlib.h>

int main() {

    int i;
    int num2[5];
    int soma = 0;
    int media;

    for(i = 0; i < 5; i++){
        printf("Digite o numero %d: ", i);
        scanf("%d", &num2[i]);
        soma = soma + num2[i];
    }

    for(i = 0; i < 5; i++){
        printf("%d", num2[i]);


    }
    media = soma / 5;
    printf("\nMedia: %d", media);
    return 0;
}
