#include <stdio.h>
#include <stdio.h>
 int main(){
    int vet[10], maior = -1000, menor = 1000;
    for(int i = 0; i < 10; i++){
        printf("Digite um valor: ");
        scanf("%d", &vet[i]);
    }
    for(int i = 0; i < 10; i++){
        if(i == 10 - 1){
            printf("%d. ", vet[i]);
        } else {
            printf("%d, ", vet[i]);
        }
        if(vet[i] < menor){
            menor = vet[i];
        }
         if(vet[i] > maior){
            maior = vet[i];
        }
    }
    printf("\nMaior valor digitado: %d.\n", maior);
    printf("Menor valor digitado: %d.", menor);

    return(0);
}


