#include <stdio.h>
#include <stdlib.h>

int main ( ) {
    int vet[10] , i;

    for (i = 0; i < 10; i++)
    {
    printf("Digite o numero de ordem %d: \n" , i +1);
    scanf(" %d" , &vet[i]);
            system("cls");
    }
        system("cls");

    for(i = 0;i < 10; i++)
    {
    if(vet[i] % 2 == 0)
    printf("%d ", vet[i]);
    }
        return 0;
}

