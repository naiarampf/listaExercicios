#include <stdio.h>
#include <stdlib.h>

int main(){

 int num[10],i = 0,k = 0, help;

    printf("Digite 10 numeros:\n");

        for(i = 0; i < 10; i++){
            printf("[%i] =", i+1);
            scanf("%d", &num[i]);
}

    printf(" << Numeros repetidos: >>\n\n");
        for(i = 0; i < 10; i++){
        for(k = i+1; k < 10; k++){

     if(num[k] == num[i]){
        help = num[i];
        printf("%d\n", help);

     }
   }
 }
return 0;
}
