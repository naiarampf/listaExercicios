#include <stdio.h>

 int main(){
    float vet[10], negat = 0, posit = 0;
    for(int i = 0; i < 10; i++){
        printf("Digite um numero: ");
        scanf("%f", &vet[i]);
    }
    printf("Numeros digitados:\n");

    for(int i = 0; i < 10; i++){
        if(i == 10 - 1){
            printf("%.2f. ", vet[i]);
        } else {
            printf("%.2f, ", vet[i]);
        }
        if (vet[i] < 0){
            negat = negat + vet[i];
        } else {
            posit = posit + vet[i];
        }
    }
    printf("\nSoma dos numeros negativos no vetor: %.2f", negat);
    printf("\nSoma dos numeros positivos no vetor: %.2f", posit);
    return 0;
}
