#include <stdlib.h>

int main(){
    int vetor[6];

    for(int x = 0; x < 6; x++){
        printf("Digite um numero: ");
        scanf("%d", &vetor[x]);
        }
    for (int y = 6; y > 0; y--){
        if( y == 0+1){
            printf("%d. ", vetor[y - 1]);

        }else{
            printf("%d, ", vetor[y - 1]);
        }
    }
}
